# Custom GPT App with Knowledge Base (Render Deployment)

This repository contains a Flask app to deploy a custom GPT endpoint on Render, with support for loading knowledge base documents.

## Files
- `main.py` : Flask app entry point with knowledge-base integration
- `requirements.txt` : Python dependencies
- `Procfile` : Tells Render how to run the app
- `README.md` : Instructions
- `knowledge-base/` : Folder containing `.docx` files with training material

## How to Deploy
1. Place your `.docx` training materials inside a folder called `knowledge-base/` at the root of this repo.
2. Push the repo to GitHub.
3. Connect GitHub repo to Render and create a new Web Service.
4. In Render, set an environment variable:
   - `OPENAI_API_KEY = your_openai_api_key`
5. Deploy.

## Usage
- Visit the Render app URL → should display: `Custom GPT with Knowledge Base is running!`
- Send a POST request to `/ask` with JSON body:
  ```json
  { "question": "How do I reschedule a meeting?" }
  ```
- GPT will use your knowledge base docs to answer.

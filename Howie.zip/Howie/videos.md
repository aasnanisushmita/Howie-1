
# Loom Video Resources

1. Navigating Tree Agent (High Level): https://www.loom.com/share/example1
2. Using Loop Chat to Change Course: https://www.loom.com/share/example2
3. Using Loop Chat in Tree Agent (Agent vs Ask Mode): https://www.loom.com/share/example3

(Note: Replace example links with your actual Loom URLs)
